function valida_envia(){
    
    if(!(document.getElementById("form").usuario.value.length<11)){
        alert("Solo hasta 10  caracteres en el usuario");
        return false;
    }
    if(!(document.getElementById("form").password.value.length<11)){
        alert("Solo hasta 10  caracteres en el password");
        return false;
    }
    return true;
    
}
