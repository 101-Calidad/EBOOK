function valida_envia(){
            var numbers = /^[0-9]+$/;
            var espaciosLetras = /^[a-zA-Z\s]*$/;        
            if(!(document.getElementById("form").cedula.value.match(numbers)&&document.getElementById("form").cedula.value.length==10)){
                alert("Solo numeros y 10 caracteres en la cedula");
                return false;
            }
            if(!(document.getElementById("form").nombres.value.match(espaciosLetras))){
                alert("Digite solo letras en el nombre");
                return false;
            }
            if(!(document.getElementById("form").apellidos.value.match(espaciosLetras))){
                alert("Digite solo letras en el apellido");
                return false;
            }
            if(!(document.getElementById("form").telefono.value.match(numbers)&&document.getElementById("form").telefono.value.length<11)){
                alert("Solo numeros y hasta 10");
                return false;
            }
            if(!(document.getElementById("form").usuario.value.length<11)){
                alert("Solo hasta 10  caracteres en el usuario");
                return false;
            }
            if(!(document.getElementById("form").password.value.length<11)){
                alert("Solo hasta 10  caracteres en el password");
                return false;
            }
            return true;
        }
            
            
            
            /*
            //valido cedula
            if (document.getElementById("form").cedula.value.length==0){
            alert("Tiene que escribir su cedula")
            document.getElementById("form").cedula.focus();
            return false ;
            }else if(document.getElementById("form").cedula.value.match(numbers))
                    {//validacion cedula correcta
                      if (document.getElementById("form").nombres.value.length==0){
                        alert("Tiene que escribir su nombre")
                        document.getElementById("form").nombres.focus();
                        return false ;
                        }else if(document.getElementById("form").nombres.value.match(espaciosLetras)){
                          //validacion nombres correcta
                          if(document.getElementById("form").apellidos.value.length==0){
                            alert("Tiene que escribir su apellido")
                            document.getElementById("form").apellidos.focus();
                            return false ;
                          }else if(document.getElementById("form").apellidos.value.match(espaciosLetras)){
                            //validacion apellidos correcta
                            if(document.getElementById("form").direccion.value.length==0){
                              alert("Tiene que escribir su direccion")
                              document.getElementById("form").direccion.focus();
                              return false ;
                              //validacion direccion correcta
                            } else if(document.getElementById("form").correo.value.length==0){
                              alert("Tiene que escribir su correo")
                              document.getElementById("form").correo.focus();
                              return false ;
                              //validacion correo ok
                            } else if(document.getElementById("form").telefono.value.length==0){
                              alert("Tiene que escribir su telefono")
                              document.getElementById("form").telefono.focus();
                              return false ;
                            } else if(document.getElementById("form").telefono.value.match(numbers)&&document.getElementById("form").telefono.value.length<11){
                              //validacion telefono ok
                              if(document.getElementById("form").usuario.value.length==0){
                                alert("Tiene que escribir su usuario")
                                document.getElementById("form").usuario.focus();
                                return false ;
                              } else if (document.getElementById("form").usuario.value.length<11){
                                //validacion usuario ok
                                if(document.getElementById("form").password.value.length==0){
                                  alert("Tiene que escribir su password")
                                  document.getElementById("form").password.focus();
                                  return false ;
                                }else if (document.getElementById("form").password.value.length<11){
                                  alert("Muchas gracias por enviar el formulario");
                                  return true;

                                }else{
                                  alert("Solo hasta 10  caracteres prro :v me vas a saturar");
                                  return false;
                                }
                              }
                              else {
                                alert("Solo hasta 10  caracteres prro :v me vas a saturar");
                                return false;
                              }
                            } else {
                              alert("Solo numeros y hasta 10");
                              return false;
                            }
                            }else{
                              alert("Digite solo letras en el apellido");
                              return false;
                            }
                        }
                        else{
                          alert("Digite solo letras en el nombre");
                          return false;
                        }
            }else {
                        alert("Digite solo numeros en la cedula");
                        return false;
                    }
                    }
            */


