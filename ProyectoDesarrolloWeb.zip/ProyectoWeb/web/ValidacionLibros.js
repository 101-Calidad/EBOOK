function valida_envia(){
            var numbers = /^[0-9]*\.?[0-9]*$/;
            if(!(document.getElementById("form").titulo.value.length<51)){
                alert("Solo hasta 50 caracteres en el titulo");
                return false;
            }//validacion titulo ok
            if(!(document.getElementById("form").autor.value.length<51)){
                alert("Solo hasta 50 caracteres en el autor");
                return false;
            }//validacion autor ok 
            if(!(document.getElementById("form").precio.value.match(numbers)&&document.getElementById("form").precio.value.length<10)){
                alert("Solo numeros en el precio");
                return false;
            }//validacion precio ok 
            if(!(document.getElementById("form").sintesis.value.length<1000)){
                alert("Solo hasta 1000 caracteres en la sintesis");
                return false;
            }//validacion sintesis ok
            if(!(document.getElementById("form").imagen.value.trim().length<100)){
                alert("Solo hasta 100 caracteres en la imagen, xfavor no dejar espacios");
                return false; 
            }//validacion imagen ok
            if(!(document.getElementById("form").cantidad.value.match(numbers)&&document.getElementById("form").cantidad.value.length<7)){
                alert("No sea imbecil solo numeros y hasta 7 cifras en cantidad");
                return false;
            }
            alert("Libro registrado :)");
            return true;

}