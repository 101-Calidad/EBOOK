package edu.ug.cisc.tienda.dao;
import edu.ug.cisc.tienda.entity.Usuario;
import java.sql.*;
import java.util.ArrayList;

public class UserDAO {
  String error;
  Connection con;
  public UserDAO()   { }
	  public void connect() throws ClassNotFoundException,
	                               SQLException, 
	                               Exception {
	    
		  String url="jdbc:postgresql://localhost:8081/desarrollo";
		  
		    //Credenciales de la base de datos
		    String usuario="postgres";
		    String contrasena="zafiro20";
		  
		  try {
	    	 //DriverManager.registerDriver(new org.postgresql.Driver());
                Class.forName("org.postgresql.Driver");
	      con = DriverManager.getConnection(url, usuario, contrasena);
	    } catch (ClassNotFoundException cnfe) {
	      throw new ClassNotFoundException(cnfe.toString());
	    } catch (SQLException sqle) {
	      throw new SQLException(sqle.toString());
	    } catch (Exception e) {
	      throw new Exception(e.toString());
	    }
	  } 

  public void disconnect() throws SQLException {
    try {
      if ( con != null ) {
        con.close();
      }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    }
  }
  
  public ResultSet listUser(String user, String pass) throws SQLException, Exception {
    //metodo que va a retornar todos los usuarios que tenga en la base de datos
	ResultSet rs = null;
    try  {
        
      String  queryString = "SELECT cedula,nombres,apellidos,direccion,correo,telefono,usuario,password,rol FROM usuarios WHERE usuario='"+user+"' AND password='"+pass+"'";
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString);   
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return rs;
  }
  public ArrayList listaUsuarios() throws SQLException, Exception {
    //metodo que va a retornar todos los libros que tenga en la base de datos
	ResultSet rs = null;
        ArrayList usuarios = new ArrayList();
    try  {
      String queryString = ("SELECT * FROM usuarios ;");
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString); 
      while(rs.next()){
          
          Usuario u =  new Usuario();
          u.setCedula(rs.getString("cedula")); 
          u.setNombres(rs.getString("nombres"));  
          u.setApellidos(rs.getString("apellidos"));
          u.setDireccion(rs.getString("direccion"));
          u.setCorreo(rs.getString("correo"));
          u.setTelefono(rs.getInt("telefono"));
          u.setUsuario(rs.getString("usuario"));
          u.setPassword(rs.getString("password"));
          u.setRol(rs.getString("rol")); 
          usuarios.add(u);        
      }     
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return usuarios;
  }
  
  public void addUsuario(Usuario u) throws SQLException, Exception {
      if (con != null) {
	try {
              PreparedStatement updateUsuarios;
              updateUsuarios = con.prepareStatement("insert into usuarios(cedula, nombres, apellidos, direccion, correo, telefono, usuario, password, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);");
              updateUsuarios.setString(1, u.getCedula());
	      updateUsuarios.setString(2, u.getNombres());
              updateUsuarios.setString(3, u.getApellidos());
              updateUsuarios.setString(4, u.getDireccion());
              updateUsuarios.setString(5, u.getCorreo());
              updateUsuarios.setInt(6, u.getTelefono());
              updateUsuarios.setString(7, u.getUsuario());
              updateUsuarios.setString(8, u.getPassword());
              updateUsuarios.setString(9, u.getRol());
	      updateUsuarios.execute();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }
  
  public Usuario buscarPorUsuario(String usuario) throws SQLException, Exception {
	    
        Statement stmt = null;
	ResultSet rs = null;
        Usuario u = new Usuario();
        
    try  {
      
      stmt = con.createStatement();
      String queryString = "SELECT * FROM usuarios l  WHERE l.usuario = '"+usuario+"'";     
      rs = stmt.executeQuery(queryString); 
      if(rs.next()){
          u.setCedula(rs.getString("cedula")); 
          u.setNombres(rs.getString("nombres")); 
          u.setApellidos(rs.getString("apellidos"));
          u.setDireccion(rs.getString("direccion"));
          u.setCorreo(rs.getString("correo"));
          u.setTelefono(rs.getInt("telefono"));
          u.setUsuario(rs.getString("usuario"));
          u.setPassword(rs.getString("password"));
          u.setRol(rs.getString("rol"));
          }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return u;
  }
  
  public void actualizar(Usuario u) throws SQLException, Exception { 
      if (con != null) {
	try {
              PreparedStatement updateUsuarios;
              updateUsuarios = con.prepareStatement("update usuarios set cedula=?,nombres=?,apellidos=?,direccion=?,correo=?,telefono=?,password=?,rol=? where usuario='"+u.getUsuario()+"';");
              updateUsuarios.setString(1, u.getCedula());
	      updateUsuarios.setString(2, u.getNombres());
              updateUsuarios.setString(3, u.getApellidos());
              updateUsuarios.setString(4, u.getDireccion());
              updateUsuarios.setString(5, u.getCorreo());
              updateUsuarios.setInt(6, u.getTelefono());
              updateUsuarios.setString(7, u.getPassword());
              updateUsuarios.setString(8, u.getRol());
              
	      updateUsuarios.executeUpdate();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }
  public void eliminar(String usuario) throws SQLException, Exception {
        Statement stmt = null;
          if (con != null) {
            try {
                stmt = con.createStatement();
                String queryString = "delete from usuarios WHERE usuario='"+usuario+"'";     
                stmt.executeUpdate(queryString); 
                  
            } catch (SQLException sqle) {
                throw new SQLException(sqle.toString());
            }
          } else {
                error = "Exception: Connection to database was lost.";
                throw new Exception(error);
            }
      }
}

