package edu.ug.cisc.tienda.dao;
import java.sql.*;
import edu.ug.cisc.tienda.entity.Book;
import edu.ug.cisc.tienda.entity.Categoria;
import edu.ug.cisc.tienda.entity.Usuario;
import edu.ug.cisc.tienda.entity.Ventas;
import java.util.ArrayList;

public class BookDAO {

  String error;
  Connection con;

  public BookDAO()   { }

	  public void connect() throws ClassNotFoundException,
	                               SQLException, 
	                               Exception {
	    
		  String url="jdbc:postgresql://localhost:8081/desarrollo";
		  
		    //Credenciales de la base de datos
		    String usuario="postgres";
		    String contrasena="zafiro20";
                    
		  
		  try {
	    	 //DriverManager.registerDriver(new org.postgresql.Driver());
                Class.forName("org.postgresql.Driver");
	      con = DriverManager.getConnection(url, usuario, contrasena);
	    } catch (ClassNotFoundException cnfe) {
	      throw new ClassNotFoundException(cnfe.toString());
	    } catch (SQLException sqle) {
	      throw new SQLException(sqle.toString());
	    } catch (Exception e) {
	      throw new Exception(e.toString());
	    }
	  } 

  public void disconnect() throws SQLException {
    try {
      if ( con != null ) {
        con.close();
      }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    }
  }

  public ResultSet viewBooks() throws SQLException, Exception {
    //metodo que va a retornar todos los libros que tenga en la base de datos
	ResultSet rs = null;
        
    try  {
      String queryString = ("SELECT * FROM libro;");
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString); 
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return rs;
  }
  
     public ArrayList listaLibros() throws SQLException, Exception {
    //metodo que va a retornar todos los libros que tenga en la base de datos
	ResultSet rs = null;
        ArrayList libros = new ArrayList();
    try  {
      String queryString = ("SELECT * FROM libro l JOIN categoria as c on l.idcategoria = c.idcategoria;");
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString); 
      while(rs.next()){
          
          Book b = new Book();
          b.setIdLibro(rs.getInt("idlibro")); 
          b.setTitulo(rs.getString("titulo"));
          b.setAutor(rs.getString("autor"));
          b.setPrecio(rs.getFloat("precio"));
          b.setCategoria(rs.getString("categoria"));
          b.setCantidad(rs.getInt("cantidad"));
          
          libros.add(b);
          
      }
      
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return libros;
  }
     
     
     public Book buscarPorId(int idLibro) throws SQLException, Exception {
	    
        Statement stmt = null;
	ResultSet rs = null;
        Book b = new Book();
        
    try  {
      
      stmt = con.createStatement();
      String queryString = "SELECT * FROM libro l JOIN categoria as c on l.idcategoria = c.idcategoria WHERE l.idlibro = "+idLibro+"";     
      rs = stmt.executeQuery(queryString); 
      if(rs.next()){

          b.setIdLibro(rs.getInt("idlibro")); 
          b.setAutor(rs.getString("autor"));
          b.setTitulo(rs.getString("titulo"));
          b.setPrecio(rs.getFloat("precio"));
          b.setIdCategoria(rs.getInt("idCategoria"));
          b.setCategoria(rs.getString("categoria"));
          b.setSintesis(rs.getString("sintesis"));
          b.setImagen(rs.getString("imagen"));
          b.setCantidad(rs.getInt("cantidad"));
                   
          }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return b;
  }
     public Book buscarPorTitulo(String titulo) throws SQLException, Exception {
	    
        Statement stmt = null;
	ResultSet rs = null;
        Book b = new Book();     
    try  {
      
      stmt = con.createStatement();
      String queryString = "SELECT cantidad FROM libro WHERE titulo = 'La senora march'";     
      rs = stmt.executeQuery(queryString); 
      if(rs.next()){
            b.setCantidad(rs.getInt("cantidad"));
                   
          }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return b;
  }
     
     
     public int buscarPorTit(String titulo) throws SQLException, Exception {
	    
        Statement stmt = null;
	ResultSet rs = null;
        Book b = new Book();
        int cantidad=0;
        
    try  {
      
      stmt = con.createStatement();
      String queryString = "SELECT cantidad FROM libro  WHERE titulo = '"+titulo+"'";     
      rs = stmt.executeQuery(queryString); 
      if(rs.next()){
          b.setCantidad(rs.getInt("cantidad")); 
          cantidad=rs.getInt("cantidad");
          }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return cantidad;
  }
     
     
     
     
     
     
     

    public ArrayList librosPorcategoria(int idCategoria) throws SQLException, Exception {
	      
        ArrayList librosPorCategoria = new ArrayList();
        
    try  {
      String queryString = "SELECT * FROM libro WHERE idCategoria = ?";
      PreparedStatement stmt = con.prepareStatement(queryString);
      stmt.setInt(1,idCategoria);      
      ResultSet rs = stmt.executeQuery(); 
      while(rs.next()){
          Book b = new Book();
          b.setAutor(rs.getString("autor"));
          b.setTitulo(rs.getString("titulo"));
          b.setPrecio(rs.getFloat("precio"));
          b.setIdCategoria(rs.getInt("categoria"));
          b.setIdLibro(rs.getInt("idlibro"));  
          librosPorCategoria.add(b);
          }
      
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return librosPorCategoria;
  }
     
     
  
   public ResultSet listarCategorias() throws SQLException, Exception {
    //metodo que va a retornar todos los libros que tenga en la base de datos
	ResultSet rs = null;
    try  {
      String queryString = ("SELECT idcategoria,categoria FROM categoria;");
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString); 
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return rs;
  }
   
  public void addBook(Book b) throws SQLException, Exception {
      if (con != null) {
	try {
              PreparedStatement updatebooks;
              updatebooks = con.prepareStatement("insert into libro(Titulo,Autor,Precio,IdCategoria,Sintesis,Imagen,Cantidad) values(?, ?, ?, ?, ?,?,?);");
              updatebooks.setString(1, b.getTitulo());
	      updatebooks.setString(2, b.getAutor());
              updatebooks.setFloat(3, b.getPrecio());
              updatebooks.setInt(4, b.getIdCategoria());
              updatebooks.setString(5, b.getSintesis());
              updatebooks.setString(6, b.getImagen());
              updatebooks.setInt(7, b.getCantidad());
	      updatebooks.executeUpdate();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }
  
   
  
 
   public void actualizar(Book b) throws SQLException, Exception { 
      if (con != null) {
	try {
              PreparedStatement updatebooks;
              updatebooks = con.prepareStatement("update libro set titulo=?,autor=?,precio=?,idcategoria=?,sintesis=?,imagen=?, cantidad=? where idlibro="+b.getIdLibro()+";");
              updatebooks.setString(1, b.getTitulo());
	      updatebooks.setString(2, b.getAutor());
              updatebooks.setFloat(3, b.getPrecio());
              updatebooks.setInt(4, b.getIdCategoria());
              updatebooks.setString(5, b.getSintesis());
              updatebooks.setString(6, b.getImagen());
              updatebooks.setInt(7, b.getCantidad());
	      updatebooks.executeUpdate();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }
   public void actualizarCantidad(String t, int C) throws SQLException, Exception { 
       int cantidad=0;
       Book b =  new Book();
      if (con != null) {
	try {
              PreparedStatement updatebooks;
              updatebooks = con.prepareStatement("update libro set cantidad=? where titulo='"+t+"';");
              updatebooks.setInt(1, C);
	      updatebooks.executeUpdate();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }

    public void eliminar(int idLibro) throws SQLException, Exception {
        Statement stmt = null;
          if (con != null) {
            try {
                stmt = con.createStatement();
                String queryString = "delete from libro WHERE idlibro="+idLibro+"";     
                stmt.executeUpdate(queryString); 
                  
            } catch (SQLException sqle) {
                throw new SQLException(sqle.toString());
            }
          } else {
                error = "Exception: Connection to database was lost.";
                throw new Exception(error);
            }
      }     
}