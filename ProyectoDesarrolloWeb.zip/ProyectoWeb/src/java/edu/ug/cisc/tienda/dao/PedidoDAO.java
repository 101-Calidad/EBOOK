package edu.ug.cisc.tienda.dao;
import java.sql.*;
import edu.ug.cisc.tienda.entity.Book;
import edu.ug.cisc.tienda.entity.Categoria;
import edu.ug.cisc.tienda.entity.Usuario;
import edu.ug.cisc.tienda.entity.Ventas;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class PedidoDAO {

  String error;
  Connection con;

  public PedidoDAO()   { }

	  public void connect() throws ClassNotFoundException,
	                               SQLException, 
	                               Exception {
	    
		  String url="jdbc:postgresql://localhost:8081/desarrollo";
		  
		    //Credenciales de la base de datos
		    String usuario="postgres";
		    String contrasena="zafiro20";
                    
		  
		  try {
	    	 //DriverManager.registerDriver(new org.postgresql.Driver());
                Class.forName("org.postgresql.Driver");
	      con = DriverManager.getConnection(url, usuario, contrasena);
	    } catch (ClassNotFoundException cnfe) {
	      throw new ClassNotFoundException(cnfe.toString());
	    } catch (SQLException sqle) {
	      throw new SQLException(sqle.toString());
	    } catch (Exception e) {
	      throw new Exception(e.toString());
	    }
	  } 

  public void disconnect() throws SQLException {
    try {
      if ( con != null ) {
        con.close();
      }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    }
  }

  public int IdVenta() throws SQLException, Exception{
      int idventa = 0;
      ResultSet rs = null;
      try  {
      String queryString = ("SELECT max(idventa) FROM Pedidos;");
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString);
      while (rs.next()) {
                idventa = rs.getInt(1);
            }
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    }
			 
    
    return idventa;
  }
  public void addVenta(Ventas v) throws SQLException, Exception {
      if (con != null) {
	try {
              PreparedStatement updateVentas;
              updateVentas = con.prepareStatement("insert into Pedidos(idventa, usuario, titulo, cantidad, precio,fecha) VALUES (?, ?, ?, ?, ?,?);");
              updateVentas.setInt(1, v.getIdventa());
              updateVentas.setString(2, v.getUsuario());
	      updateVentas.setString(3, v.getTitulo());
              updateVentas.setInt(4, v.getCantidad());
              updateVentas.setFloat(5, v.getPrecio());
              updateVentas.setString(6, v.getFecha());
              
	      updateVentas.executeUpdate();
	} catch (SQLException sqle) {
            throw new SQLException(sqle.toString());
	}
      } else {
            error = "Exception: Connection to database was lost.";
            throw new Exception(error);
	}
  }
  
  public ArrayList buscarPorUsuario(String usuario) throws SQLException, Exception {
	    
      ResultSet rs = null;
        ArrayList ventas = new ArrayList();
    try  {
      String queryString = "SELECT * FROM pedidos p WHERE p.usuario = '"+usuario+"'";
      Statement stmt = con.createStatement();
      rs = stmt.executeQuery(queryString); 
      while(rs.next()){
          
          Ventas v = new Ventas();

          v.setTitulo(rs.getString("titulo")); 
          v.setCantidad(rs.getInt("cantidad"));
          v.setPrecio(rs.getFloat("precio"));  
          v.setFecha(rs.getString("fecha"));
          ventas.add(v);      
      }     
    } catch (SQLException sqle) {
      throw new SQLException(sqle.toString());
    } catch (Exception e) {
      throw new Exception(e.toString());			 
    }
    return ventas;  
      
  }
  
  public String FechaBD() {
        Calendar calendar = Calendar.getInstance();    
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fecha = sdf.format(calendar.getTime());
        return fecha;
    }
        
    
}